module.exports=[
    150, // in seconds
    ["0xd45f7FB66Ad897787b23B27e4078f0d5999e52b6"],//proposers array
    ["0xd45f7FB66Ad897787b23B27e4078f0d5999e52b6"],//excutors array
    "0x0767b8C4491dDb74711365c0f858b2925377A27c" // metamask address of deployer account
]

